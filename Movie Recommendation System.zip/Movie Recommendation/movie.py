import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors
import os

# -------------------------------------------------
# Page configuration
# -------------------------------------------------
st.set_page_config(page_title="Movie Recommender", page_icon="🎬", layout="wide")

# -------------------------------------------------
# CSS
# -------------------------------------------------
st.markdown("""
<style>
.stApp { background-color: #2D3C59; }
html, body, [class*="css"] { color: white !important; }
h1, h2, h3, h4, h5, h6, label, p, span { color: white !important; }

.stTextInput input {
    background-color: white;
    color: black !important;
    border-radius: 8px;
}

.stSelectbox div[data-baseweb="select"] > div {
    background-color: white !important;
    border-radius: 8px;
}

.stSelectbox div[data-baseweb="select"] span {
    color: #0b1f3a !important;
    font-weight: 600;
}

div[role="listbox"] {
    background-color: #0b1f3a !important;
    border-radius: 8px;
}

div[role="listbox"] span {
    color: white !important;
}

div[role="listbox"] div:hover {
    background-color: #163a66 !important;
}

.stButton > button {
    background-color: #ffcc00;
    color: black !important;
    border-radius: 10px;
    font-weight: bold;
}
</style>
""", unsafe_allow_html=True)

# -------------------------------------------------
# User Database (CSV)
# -------------------------------------------------
USER_DB = "users.csv"

if not os.path.exists(USER_DB):
    pd.DataFrame(columns=["username", "password"]).to_csv(USER_DB, index=False)

def load_users():
    return pd.read_csv(USER_DB)

def save_user(username, password):
    users = load_users()
    users.loc[len(users)] = [username, password]
    users.to_csv(USER_DB, index=False)

# -------------------------------------------------
# Session State
# -------------------------------------------------
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "current_user" not in st.session_state:
    st.session_state.current_user = None

# -------------------------------------------------
# LOGIN / SIGNUP PAGE
# -------------------------------------------------
def login_page():
    st.title("🎬 Welcome to Movie Recommender")
    users_df = load_users()

    tab1, tab2 = st.tabs(["Login", "Sign Up"])

    # -------- LOGIN --------
    with tab1:
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")

        if st.button("Login"):
            if username in users_df.username.values:
                real_pass = users_df.loc[
                    users_df.username == username, "password"
                ].values[0]
                if password == real_pass:
                    st.session_state.logged_in = True
                    st.session_state.current_user = username
                    st.rerun()
                else:
                    st.error("Wrong password")
            else:
                st.error("User not found")

    # -------- SIGNUP --------
    with tab2:
        new_user = st.text_input("Choose Username")
        new_pass = st.text_input("Choose Password", type="password")
        confirm = st.text_input("Confirm Password", type="password")

        if st.button("Create Account"):
            if new_user in users_df.username.values:
                st.error("Username already exists")
            elif new_pass != confirm:
                st.error("Passwords do not match")
            elif len(new_pass) < 6:
                st.error("Password must be at least 6 characters")
            else:
                save_user(new_user, new_pass)
                st.session_state.logged_in = True
                st.session_state.current_user = new_user
                st.rerun()

# -------------------------------------------------
# MOVIE PAGE
# -------------------------------------------------
def movie_page():
    st.title("🎬 Movie Recommendation System")
    st.write(f"Welcome, **{st.session_state.current_user}**")

    if st.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.current_user = None
        st.rerun()

    @st.cache_data
    def load_data():
        df = pd.read_csv("movies_content.csv")
        df = df[['name', 'description']]
        df.drop_duplicates(inplace=True)
        df.dropna(inplace=True)
        df.reset_index(drop=True, inplace=True)
        df['name'] = df['name'].str.lower()
        return df

    @st.cache_resource
    def train_model(df):
        tf = TfidfVectorizer()
        matrix = tf.fit_transform(df.description).toarray()
        model = NearestNeighbors(metric="cosine")
        model.fit(matrix)
        return model, matrix

    df = load_data()
    model, matrix = train_model(df)

    movie = st.selectbox("Choose a movie", df.name.str.title())

    if st.button("Get Recommendations"):
        mi = df[df.name == movie.lower()].index[0]
        _, idx = model.kneighbors([matrix[mi]], n_neighbors=5)

        for i in idx[0][1:]:
            st.write(f"🎥 **{df.loc[i, 'name'].title()}**")
            with st.expander("View Description"):
                st.write(df.loc[i, 'description'])

# -------------------------------------------------
# ROUTING (IMPORTANT FIX)
# -------------------------------------------------
if st.session_state.logged_in:
    movie_page()
else:
    login_page()
